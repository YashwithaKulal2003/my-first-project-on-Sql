<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: register.php");
    exit;
}
// Establish database connection
$con = mysqli_connect('localhost', 'root');
mysqli_select_db($con, 'mywebsite');

// Check if a category filter is applied
if (isset($_GET['category'])) {
    $category = mysqli_real_escape_string($con, $_GET['category']);
    $sql = "SELECT * FROM products WHERE type = '$category'";
} elseif (isset($_GET['search_query'])) {
    $search_query = mysqli_real_escape_string($con, $_GET['search_query']);
    // Construct the SQL query to search for products based on title, description, brandname, etc.
    $sql = "SELECT * FROM products WHERE 
            title LIKE '%$search_query%' OR 
            description LIKE '%$search_query%' OR 
            brandname LIKE '%$search_query%' OR 
            type LIKE '%$search_query%'";
} else {
    // Select three random products from the database
    $sql = "SELECT * FROM products ORDER BY RAND() LIMIT 16";
}

$featured = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>TechBuy</title>
    <h2>TechBuy– Smart Choices for Smart Devices🛃🎉🎉</h2>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="custom.css">

    <style>
        /* Custom CSS for the index page */

        /* Navbar */
        body{
            background-image:url("pic1.gif") ;
        }
        .navbar {
            background-color: #343a40 !important;
        }

        .navbar-brand img {
    width: 120px; /* Adjust the width as needed */
    margin-right: 10px;
}

        .navbar-brand {
            color: #fff !important;
        }

        .nav-link {
            color: #fff !important;
        }

        /* Container */
        .container {
            margin-top: 50px;
        }

        /* Product Card */
        .product-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .product-card h4 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .product-card .price {
            font-size: 16px;
            font-weight: bold;
            color: #007bff;
        }

        .product-card .desc {
            font-size: 14px;
            color: #666;
        }

        .product-card .bname {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }

        .btn-more {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 16px;
            font-size: 14px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        .btn-more:hover {
            background-color: #0056b3;
            color: #fff;
            text-decoration: none;
        }

        .btn-buy {
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 16px;
            font-size: 14px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        .btn-buy:hover {
            background-color: #218838;
            color: #fff;
            text-decoration: none;
        }

        /* Modal */
        .modal-content {
            border-radius: 10px;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <?php include 'navbar.php' ?>
    <div class="container mt-5">
        <div class="row">
            <?php while ($products = mysqli_fetch_assoc($featured)): ?>
                <div class="col-md-4">
                    <div class="product-card">
                        <h4><?= $products['title']; ?></h4>
                        <img src="<?= $products['image']; ?>" alt="<?= $products['title']; ?>">
                        <p class="price">Rs <?= $products['price']; ?></p>
                        <a href="details.php?id=<?= $products['prod_id']; ?>" class="btn btn-more" data-toggle="modal" data-target="#detailsModal<?= $products['prod_id']; ?>">More</a>
                        <!-- Buy Button -->
                        <a href="<?php echo isset($_SESSION['user_id']) ? 'buy.php?action=add&product_id=' . $products['prod_id'] : 'login.php'; ?>" class="btn btn-primary btn-buy">Add to cart</a>
                    
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php mysqli_data_seek($featured, 0); // Reset the result set pointer to fetch data again from the beginning ?>
    <?php while ($products = mysqli_fetch_assoc($featured)): ?>
        <div class="modal fade" id="detailsModal<?= $products['prod_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="detailsModalLabel<?= $products['prod_id']; ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="detailsModalLabel<?= $products['prod_id']; ?>">Product Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h4><?= $products['title']; ?></h4>
                        <img src="<?= $products['image']; ?>" alt="<?= $products['title']; ?>" />
                        <p class="price">Rs <?= $products['price']; ?></p>
                        <p class="desc"><?= $products['description']; ?></p>
                        <p class="bname">Brand: <?= $products['brandname']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php include 'footer.php' ?>
</body>

</html>
