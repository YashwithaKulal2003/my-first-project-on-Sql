-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2024 at 06:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mywebsite`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(10) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `admin_password` varchar(10) NOT NULL,
  `admin_contact` bigint(12) NOT NULL,
  `admin_address` text NOT NULL,
  `admin_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`, `admin_contact`, `admin_address`, `admin_email`) VALUES
('yuktha123', 'yukthaks', 'admin1', 1234567890, 'vittla', 'yukth@gmail.com');
('yashwitha', 'yashwitha', 'admin2', 9908776550, 'kalladka', 'yashu@#@gmail.com')
-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `prod_id` int(10) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`prod_id`, `user_id`, `cart_id`, `quantity`) VALUES
(11, '4', 76, 1),
(17, '1', 83, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_no` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `total_products` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_no`, `category_name`, `total_products`) VALUES
(1, 'laptop', 4),
(2, 'mobile', 9),
(3, 'headphone', 3),
(4, 'accesssories', 0);
(5,`smartwatch`,1);
(6,`earphone`,1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `prod_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `pay_status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_name`, `order_date`, `status`, `prod_id`, `quantity`, `total_price`, `pay_status`) VALUES
(24, 2, 'Samsung M14', '2024-03-16', 'Cancelled', 2, 1, 0.00, 'Pending'),
(25, 2, 'Iphone 15 pro', '2024-03-16', 'Cancelled', 6, 1, 0.00, 'Pending'),
(26, 2, 'spectre', '2024-03-16', 'Pending', 1, 1, 0.00, 'Pending'),
(27, 2, 'Samsung S21 FE', '2024-03-16', 'Pending', 7, 1, 0.00, 'Pending'),
(28, 1, 'Iphone 15 pro', '2024-03-16', NULL, 6, 1, 0.00, 'Successful'),
(34, 4, 'Iphone 13', '2024-03-18', 'Pending', 12, 1, 60000.00, 'Pending'),
(35, 4, 'boat rockerz', '2024-03-18', 'Shipped', 16, 1, 2000.00, 'Successful'),
(47, 1, 'boat rockerz', '2024-03-18', 'Shipped', 16, 1, 2000.00, 'Successful');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_id` int(5) NOT NULL,
  `type` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `brandname` varchar(150) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `featured` tinyint(4) NOT NULL,
  `category_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_id`, `type`, `title`, `price`, `brandname`, `image`, `description`, `featured`, `category_no`) VALUES
(1, 'laptop', 'spectre', 80000.00, 'HP', '/mywebsite/images/spectre.jpeg', 'hp laptop', 1, 1),
(2, 'mobile', 'Samsung M14', 36000.00, 'Samsung', '/mywebsite/images/samsungm14.jpg', 'Release date	8th March 2023\r\nLaunched in India	Yes\r\nForm factor	Touchscreen\r\nDimensions (mm)	166.80 x 77.20 x 9.40\r\nWeight (g)	206.00\r\nBattery capacity (mAh)	6000', 1, 2),
(3, 'mobile', 'Vivo Y200', 19000.00, 'Vivo', '/mywebsite/images/vivoy200.png', ' 120Hz Ultra Vision AMOLED Display Stylish Glass Design 64MP OIS Anti-Shake Camera Wedding Style Portrait', 1, 2),
(4, 'laptop', 'hp pavillion', 70000.00, 'HP', '/mywebsite/images/pavilion.jpeg', 'hp pavillion laptop', 0, 1),
(6, 'mobile', 'Iphone 15 pro', 90000.00, 'Iphone', '/mywebsite/images/iphone.jpeg', 'Apple iphone 15 pro', 0, 2),
(7, 'mobile', 'Samsung S21 FE', 24000.00, 'Samsung', '/mywebsite/images/s21.jpg', '8 GB RAM | 256 GB ROM\r\n16.26 cm (6.4 inch) Full HD+ Display\r\n12MP + 12MP + 8MP (OIS) | 32MP Front Camera\r\n4500 mAh Lithium-ion Battery\r\nSnapdragon 888 Processor\r\n', 0, 2),
(8, 'mobile', 'Samsung M34', 30000.00, 'Samsung', '/mywebsite/images/m34.jpg', '16.42cm (6.5\") FHD+  120Hz sAmoled Display\r\n50MP (OIS) Triple Camera, Nightography  13MP Selfie Camera\r\n6000mAh Battery\r\n4 times of Android Updates, 5 Years Security Updates\r\n', 1, 2),
(9, 'mobile', 'Vivo T2 Pro', 35000.00, 'Vivo', '/mywebsite/images/vivot2pro.png', 'Vivo T2 Pro 5G mobile was launched on 22nd September 2023. The phone comes with a 120 Hz refresh rate 6.78-inch touchscreen display offering a resolution of 1080x2400 pixels (FHD). ', 2, 2),
(10, 'mobile', 'Vivo V29', 19000.00, 'Vivo', '/mywebsite/images/vivov29.jpeg', 'Vivo V29 mobile was launched on 4th October 2023. The phone comes with a 120 Hz refresh rate 6.78-inch touchscreen display offering a resolution of 2800x1260 pixels (QHD+).', 3, 2),
(11, 'mobile', 'Vivo Y27', 30000.00, 'Vivo', '/mywebsite/images/vivoy27.png', '•	Camera: Dual 50MP+2MP Rear Camera | 8MP Selfie Camera with rear flash, night mode\r\n•	Display: 16.86 cm (6.64 inch) FHD+ LCD Sunlight Display for enhanced outdoor display\r\n•	Memory & SIM: 6 GB RAM | 128 GB internal memory with next Gen extendede RAM technology 3.0,\r\n•	Battery & charging: 44W FlashCharge with 5000 mAh battery\r\n', 1, 2),
(12, 'mobile', 'Iphone 13', 60000.00, 'Apple Iphone', '/mywebsite/images/iphone13.jpeg', '•	Super Retina XDR display\r\n•	15.4 cm / 6.1″ (diagonal) all screen OLED display\r\n•	2532x1170-pixel resolution at 460 ppi\r\n•	HDR display\r\n•	True Tone\r\n•	Wide colour (P3)\r\n•	Haptic Touch\r\n•	20,00,000:1 contrast ratio (typical)\r\n•	800 nits max brightness (typical); 1,200 nits max brightness (HDR)\r\n', 2, 2),
(13, 'laptop', 'Dell Latitude', 36000.00, 'Dell', '/mywebsite/images/dell_lat.jpg', 'Dell 15 Laptop, Intel 12th Gen Core i3-1215U Proc/8GB DDR4/512GB SSD/Intel UHD Graphic/15.6\" (38cm) FHD Display/Spill-Resistant Keyboard/Win11+MSO\21/15 Month McAfee/Black/Thin & Light 1.69kg', 3, 1),
(14, 'laptop', 'HP ZBook', 89999.00, 'HP', '/mywebsite/images/hp_zbook.jpeg', 'HP ZBook 15 G2 is a Windows 7 laptop with a 15.60-inch display that has a resolution of 1920x1080 pixels. It is powered by a Core i7 processor and it comes with 8GB of RAM. The HP ZBook 15 G2 packs 256GB of SSD storage.', 1, 1),
(16, 'headphone', 'boat rockerz', 2000.00, 'Boat', '/mywebsite/images/boat.jpeg', 'boat headphone', 1, 3),
(17, 'headphone', 'sony headphone', 12000.00, 'Sony', '/mywebsite/images/boat.jpeg', 'its a sony head phone', 0, NULL);

--
-- Triggers `products`
--
DELIMITER $$
CREATE TRIGGER `update_category_after_insert` AFTER INSERT ON `products` FOR EACH ROW BEGIN
    DECLARE category_count INT;
    
    -- Get the count of products for the category of the newly inserted product
    SELECT COUNT(*) INTO category_count FROM products WHERE type = NEW.type;
    
    -- Update the category table with the new count
    UPDATE category SET total_products = category_count WHERE category_name = NEW.type;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_total_products` AFTER INSERT ON `products` FOR EACH ROW BEGIN
    UPDATE category
    SET total_products = total_products + 1
    WHERE category_name = NEW.type;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_contact` bigint(10) NOT NULL,
  `user_address` text NOT NULL,
  `user_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_contact`, `user_address`, `user_password`) VALUES
(1, 'Yuktha K S', 'yuktha@gmail.com', 1234567890, 'vittla', '$2y$10$B1suCYiDOlAnQLaqNPQvXuGtxdXJfdfwMWI4NwOK6ngkm2i3la9dm'),
(2, 'Yashaswi', 'yashu@gmail.com', 1234567890, 'vittla', '$2y$10$FeSU3XEj0fI9ken3V9r2gOBkNF77ReIuF12VXR3pHGkVLOEGQvf7K'),
(4, 'Yuktha KS', 'yuktha@gmail.com', 9988776655, 'Vittla', '$2y$10$Gdz532pCakr/Q49hN4gVB.VyLz6KTy5QQxxMn3am.fc/Fszen4aBy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_no`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_product_id` (`prod_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_id`),
  ADD KEY `fk_category` (`category_no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `prod_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_product_id` FOREIGN KEY (`prod_id`) REFERENCES `products` (`prod_id`),
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_category` FOREIGN KEY (`category_no`) REFERENCES `category` (`category_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
