<?php
// Include database connection code
include_once "db_connection.php";

// Start session to access cart items
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Check if the "Buy Now" button is clicked
    if (isset($_POST['buy'])) {
        // Retrieve cart items from the database for the current user
        $cart_sql = "SELECT products.*, cart.cart_id FROM products INNER JOIN cart ON products.prod_id = cart.prod_id WHERE cart.user_id = ?";
        $stmt_cart = $connection->prepare($cart_sql);
        $stmt_cart->bind_param("i", $user_id);
        $stmt_cart->execute();
        $cart_result = $stmt_cart->get_result();

        if (!$cart_result) {
            die("Error fetching cart items: " . $connection->error);
        }

        // Check if cart has items
        if ($cart_result->num_rows > 0) {
            $cart_items = $cart_result->fetch_all(MYSQLI_ASSOC);
            
            // Insert cart items into the orders table
            $insert_order_sql = "INSERT INTO orders (user_id, prod_id, product_name, quantity, total_price, order_date, status) VALUES (?, ?, ?, ?, ?, NOW(), 'Pending')";
            $stmt_insert_order = $connection->prepare($insert_order_sql);
            foreach ($cart_items as $item) {
                $stmt_insert_order->bind_param("iisid", $user_id, $item['prod_id'], $item['title'], $item['quantity'], $item['price']);
                $stmt_insert_order->execute();
            }

            // Clear the cart after successful purchase
            $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
            $stmt_clear_cart = $connection->prepare($clear_cart_sql);
            $stmt_clear_cart->bind_param("i", $user_id);
            $stmt_clear_cart->execute();

            // Redirect to the purchase_confirmation.php
            header("Location: purchase_confirmation.php");
            exit();
        } else {
            // Cart is empty, handle accordingly
            echo "Your cart is empty. Please add items to your cart before proceeding.";
        }
    }

    // Check if the "Buy" button for individual items is clicked
    if (isset($_POST['buy_individual'])) {
        $prod_id = $_POST['prod_id'];
        $quantity = $_POST['quantity'];

        // Fetch product details
        $product_sql = "SELECT title, price FROM products WHERE prod_id = ?";
        $stmt_product = $connection->prepare($product_sql);
        $stmt_product->bind_param("i", $prod_id);
        $stmt_product->execute();
        $product_result = $stmt_product->get_result();
        $product = $product_result->fetch_assoc();

        // Insert the individual item into the orders table
        $insert_order_sql = "INSERT INTO orders (user_id, prod_id, product_name, quantity, total_price, order_date, status) VALUES (?, ?, ?, ?, ?, NOW(), 'Pending')";
        $stmt_insert_order = $connection->prepare($insert_order_sql);
        $stmt_insert_order->bind_param("iisid", $user_id, $prod_id, $product['title'], $quantity, $product['price']);
        $stmt_insert_order->execute();

        // Remove the purchased item from the cart
        $remove_cart_sql = "DELETE FROM cart WHERE user_id = ? AND prod_id = ?";
        $stmt_remove_cart = $connection->prepare($remove_cart_sql);
        $stmt_remove_cart->bind_param("ii", $user_id, $prod_id);
        $stmt_remove_cart->execute();

        // Redirect to the purchase_confirmation.php
        header("Location: purchase_confirmation.php");
        exit();
    }

} else {
    // User is not logged in, handle accordingly
    echo "User is not logged in.";
}
?>
