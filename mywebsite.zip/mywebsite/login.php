<?php
session_start();
include_once "db_connection.php";

$username = $password = "";
$username_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["user_name"]))) {
        $username_err = "Please enter a username.";
    } else {
        $username = trim($_POST["user_name"]);
    }

    // Validate password
    if (empty(trim($_POST["user_password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["user_password"]);
    }

    // Check input errors before querying the database
    if (empty($username_err) && empty($password_err)) {
        $sql = "SELECT user_id, user_name, user_password FROM user WHERE user_name = ?";
        if ($stmt = mysqli_prepare($connection, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = $username;
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            session_start();
                            $_SESSION["loggedin"] = true;
                            $_SESSION["user_id"] = $id;
                            $_SESSION["user_name"] = $username;
                            header("location: index.php");
                        } else {
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else {
                    $username_err = "No account found with that username.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($connection);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:antiquewhite;
           
               }
        .container {
            width: 30%;
            margin: 0 auto;
            padding: 10px;
            background-color:bisque;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0.1, 0.1);
        }
        h2 {
            text-align: left;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="password"] {
            width: 50%;
            padding:  10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
             box-sizing:border-box;
        }
        .error {
            color: red;
        }
        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        p {
            text-align: left;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Login</h2><br>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label>
        <input type="text" id="username" name="user_name" value="<?php echo $username; ?>" required>
        <span class="error"><?php echo $username_err; ?></span><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="user_password" required>
        <span class="error"><?php echo $password_err; ?></span><br><br>
        <button type="submit">Login</button>
    </form>
    <br><br>
    <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
</body>
</html>
