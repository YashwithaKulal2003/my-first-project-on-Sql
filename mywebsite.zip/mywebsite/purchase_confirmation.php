<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Confirmation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Purchase Confirmation</h1>
        
        <!-- Payment Options Form -->
        <form method="post" action="process_payment.php">
            <h3>Select Payment Method:</h3>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="paypal" checked>
                <label class="form-check-label" for="paypal">
                    PayPal
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="payment_method" id="credit_card" value="credit_card">
                <label class="form-check-label" for="credit_card">
                    Credit Card
                </label>
            </div>
            <!-- Add more payment options as needed -->

            <button type="submit" class="btn btn-primary mt-3">Proceed to Payment</button>
        </form>

        
        
        <!-- Cancel Order Button -->
        <a href="index.php" class="btn btn-secondary mt-3">Cancel Order</a>
    </div>
</body>
</html>
