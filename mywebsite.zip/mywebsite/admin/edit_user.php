<?php
// Start session
session_start();

// Check if admin is logged in
if (!isset($_SESSION["admin_id"])) {
    // Redirect to admin login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Include database connection code or functions
include_once "db_connection.php";

// Check if user ID is provided via POST request
if(isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Fetch user details from the database based on user ID
    $query = "SELECT * FROM user WHERE user_id = '$user_id'";
    $result = mysqli_query($connection, $query);

    if($result && mysqli_num_rows($result) > 0) {
        // User found, fetch user data
        $user_data = mysqli_fetch_assoc($result);
    } else {
        // User not found, redirect to manage users page
        header("Location: manage_users.php");
        exit();
    }
} else {
    // User ID not provided, redirect to manage users page
    header("Location: manage_users.php");
    exit();
}

// Check if form is submitted for updating user details
if(isset($_POST['update_user'])) {
    // Retrieve updated user details from the form
    $updated_user_name = mysqli_real_escape_string($connection, $_POST['user_name']);
    $updated_user_email = mysqli_real_escape_string($connection, $_POST['user_email']);
    $updated_user_contact = mysqli_real_escape_string($connection, $_POST['user_contact']);
    $updated_user_address = mysqli_real_escape_string($connection, $_POST['user_address']);

    // Update user details in the database
    $query = "UPDATE user SET user_name = '$updated_user_name', user_email = '$updated_user_email', user_contact = '$updated_user_contact', user_address = '$updated_user_address' WHERE user_id = '$user_id'";
    $result = mysqli_query($connection, $query);

    if($result) {
        // User details updated successfully, redirect to manage users page
        header("Location: manage_users.php");
        exit();
    } else {
        // Error updating user details
        echo "Error updating user details: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit User</h1>
        <!-- Create a form to update user details -->
        <form method="POST">
            <label for="user_name">Username:</label>
            <input type="text" id="user_name" name="user_name" value="<?php echo $user_data['user_name']; ?>">
            
            <label for="user_email">Email:</label>
            <input type="email" id="user_email" name="user_email" value="<?php echo $user_data['user_email']; ?>">
            
            <label for="user_contact">Contact:</label>
            <input type="text" id="user_contact" name="user_contact" value="<?php echo $user_data['user_contact']; ?>">
            
            <label for="user_address">Address:</label>
            <input type="text" id="user_address" name="user_address" value="<?php echo $user_data['user_address']; ?>">
            
            <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
            <input type="submit" name="update_user" value="Update">
        </form>
        <a href="manage_users.php">Back to Manage Users</a>
        <a href="admin_dashboard.php">Back to Dashboard</a>
        <a href="admin_logout.php">Logout</a>
    </div>
</body>
</html>
