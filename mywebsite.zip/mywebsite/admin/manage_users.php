<?php
// Start session
session_start();

// Check if admin is logged in
if (!isset($_SESSION["admin_id"])) {
    // Redirect to admin login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Include database connection code or functions
include_once "db_connection.php";

// Fetch all users from the database
$query = "SELECT * FROM user";
$result = mysqli_query($connection, $query);

// Check if user data is retrieved successfully
if ($result && mysqli_num_rows($result) > 0) {
    // user data fetched successfully
    $users = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    // No user found
    $users = [];
}

// Function to delete user by user ID
function deleteUser($connection, $user_id) {
    $query = "DELETE FROM user WHERE user_id = '$user_id'";
    $result = mysqli_query($connection, $query);
    if ($result) {
        // User deleted successfully
        return true;
    } else {
        // Error deleting user
        return false;
    }
}

// Function to get orders for a user
function getUserOrders($connection, $user_id) {
    $query = "SELECT * FROM orders WHERE user_id = '$user_id'";
    $result = mysqli_query($connection, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        // Orders found for the user
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        // No orders found for the user
        return [];
    }
}

// Check if delete request is made
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    // Call the delete function
    if (deleteUser($connection, $user_id)) {
        // Reload the page to reflect changes
        header("Location: manage_users.php");
        exit();
    } else {
        // Handle deletion error
        echo "Error deleting user.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: antiquewhite;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 30px;
            color: #343a40;
        }

        p {
            text-align: center;
            margin-bottom: 20px;
            color: #6c757d;
        }

        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: separate;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
            color: #495057;
        }

        th {
            background-color: mediumpurple;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
        }

        td button {
            padding: 8px 16px;
            background-color: red;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }

        td button:hover {
            background-color: #c82333;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            color: #0056b3;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #0056b3;
        }

        /* Optional: Add margin between buttons */
        .button + .button {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h1>Manage Users</h1>
    <p>List of registered users:</p>
    <table>
        <tr>
            <th>User ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Orders</th>
            <th>Action</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo $user['user_id']; ?></td>
            <td><?php echo $user['user_name']; ?></td>
            <td><?php echo $user['user_email']; ?></td>
            <td><?php echo $user['user_contact']; ?></td>
            <td><?php echo $user['user_address']; ?></td>
            <td>
                <ul>
                    <?php $orders = getUserOrders($connection, $user['user_id']); ?>
                    <?php foreach ($orders as $order): ?>
                        <li><?php echo $order['product_name']; ?></li>
                    <?php endforeach; ?>
                </ul>
            </td>
            <td>
                <form method="POST" action="edit_user.php" style="display: inline;">
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                    <button type="submit" name="edit_user">Edit</button>
                </form>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                    <button type="submit" name="delete_user">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <button class="button" onclick="window.location.href='admin_dashboard.php'">Back to Dashboard</button>
    <button class="button" onclick="window.location.href='admin_logout.php'">Logout</button>
</body>
</html>
