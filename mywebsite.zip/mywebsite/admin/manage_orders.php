<?php
// Include database connection code
include_once "db_connection.php";

// Fetch all orders from the database
$orders_sql = "SELECT * FROM orders";
$result = $connection->query($orders_sql);

// Check if there are any orders
if ($result->num_rows > 0) {
    $orders = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $orders = array();
}

// Check if the "Update Status" button is clicked
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    // Update the status of the order in the database
    $update_sql = "UPDATE orders SET status = ? WHERE order_id = ?";
    $stmt_update = $connection->prepare($update_sql);
    $stmt_update->bind_param("si", $new_status, $order_id);
    $stmt_update->execute();

    // Redirect to the same page to reflect the updated status
    header("Location: manage_orders.php");
    exit();
}

// Check if the "Update Payment Status" button is clicked
if (isset($_POST['update_pay_status'])) {
    $order_id = $_POST['order_id'];
    $new_pay_status = $_POST['pay_status'];

    // Update the payment status of the order in the database
    $update_sql = "UPDATE orders SET pay_status = ? WHERE order_id = ?";
    $stmt_update = $connection->prepare($update_sql);
    $stmt_update->bind_param("si", $new_pay_status, $order_id);
    $stmt_update->execute();

    // Redirect to the same page to reflect the updated status
    header("Location: manage_orders.php");
    exit();
}

// Check if the "Delete Order" button is clicked
if (isset($_POST['delete_order'])) {
    $order_id = $_POST['order_id'];

    // Delete the order from the database
    $delete_sql = "DELETE FROM orders WHERE order_id = ?";
    $stmt_delete = $connection->prepare($delete_sql);
    $stmt_delete->bind_param("i", $order_id);
    $stmt_delete->execute();

    // Redirect to the same page to reflect the deletion
    header("Location: manage_orders.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Styles here */
    </style>
</head>
<body>
    <!-- HTML content here -->
    <div class="container">
        <h2>Manage Orders</h2>
        <a href="admin_dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User ID</th>
                    <th>Product ID</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Payment Status</th> <!-- Added column -->
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?php echo $order['order_id']; ?></td>
                        <td><?php echo $order['user_id']; ?></td>
                        <td><?php echo $order['prod_id']; ?></td>
                        <td><?php echo $order['quantity']; ?></td>
                        <td><?php echo $order['total_price']; ?></td>
                        <td>
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <select name="status">
                                    <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="Processing" <?php if ($order['status'] == 'Processing') echo 'selected'; ?>>Processing</option>
                                    <option value="Shipped" <?php if ($order['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
                                    <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                                    <!-- Add more status options as needed -->
                                </select>
                                <button type="submit" class="btn btn-primary" name="update_status">Update Status</button>
                            </form>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <select name="pay_status">
                                    <option value="Pending" <?php if ($order['pay_status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="Successful" <?php if ($order['pay_status'] == 'Successful') echo 'selected'; ?>>Successful</option>
                                    <!-- Add more pay status options as needed -->
                                </select>
                                <button type="submit" class="btn btn-primary" name="update_pay_status">Update Payment Status</button>
                            </form>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                <button type="submit" class="btn btn-danger" name="delete_order">Delete Order</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
