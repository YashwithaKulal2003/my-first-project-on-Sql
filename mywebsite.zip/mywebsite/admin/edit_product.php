<?php
include_once "db_connection.php";

$prod_id = '';
$type = '';
$title = '';
$price = '';
$brandname = '';
$description = '';
$featured = '';
$image = '';

if (isset($_GET['id'])) {
    $prod_id = $_GET['id'];
    $query = "SELECT * FROM products WHERE prod_id = $prod_id";
    $result = mysqli_query($connection, $query);
    $product = mysqli_fetch_assoc($result);

    if ($product) {
        $type = $product['type'];
        $title = $product['title'];
        $price = $product['price'];
        $brandname = $product['brandname'];
        $description = $product['description'];
        $featured = $product['featured'];
        $image = $product['image'];
    } else {
        // Handle product not found
        echo "Product not found.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <!-- Add any necessary CSS stylesheets or external libraries here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
            resize: vertical;
        }

        input[type="checkbox"] {
            margin-right: 5px;
            vertical-align: middle;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Edit Product</h2>
    <form method="post" action="save_edit_product.php" enctype="multipart/form-data">
        <!-- Hidden input field for prod_id -->
        <input type="hidden" name="prod_id" value="<?php echo $prod_id; ?>">

        <label for="type">Type:</label>
        <input type="text" id="type" name="type" value="<?php echo $type; ?>" required><br><br>

        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo $title; ?>" required><br><br>

        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo $price; ?>" required><br><br>

        <label for="brandname">Brand:</label>
        <input type="text" id="brandname" name="brandname" value="<?php echo $brandname; ?>" required><br><br>

        <label for="description">Description:</label><br>
        <textarea id="description" name="description" required><?php echo $description; ?></textarea><br><br>

        <label for="featured">Featured:</label>
        <input type="checkbox" id="featured" name="featured" <?php echo ($featured == 1) ? 'checked' : ''; ?>><br><br>

        <label for="image">Image:</label>
        <input type="file" id="image" name="image"><br><br>
        
        <?php if (!empty($image)): ?>
            <img src="<?php echo $image; ?>" alt="Product Image" width="100"><br><br>
        <?php endif; ?>
        
        <button type="submit">Save</button>
    </form>
</body>
</html>
