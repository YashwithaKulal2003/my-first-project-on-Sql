<?php
// Start session

session_start();

// Check if admin is logged in
if (!isset($_SESSION["admin_id"])) {
    // Redirect to admin login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Include database connection code or functions
include_once "db_connection.php";

// Fetch admin details from the database
$admin_id = $_SESSION["admin_id"];
$query = "SELECT * FROM admin WHERE admin_id = '$admin_id'";
$result = mysqli_query($connection, $query);

// Check if admin data is retrieved successfully
if ($result && mysqli_num_rows($result) == 1) {
    $admin_data = mysqli_fetch_assoc($result);
    $admin_name = $admin_data["admin_name"];
} else {
    // Unable to fetch admin data, redirect to login page
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .frame {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #ccc; /* Frame border */
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .container {
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .btn {
            background-color: #f5f5f5;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        a {
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            color: #0056b3;
        }

        p {
            text-align: center;
            margin-top: 20px;
        }

        a.logout-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #dc3545;
            text-decoration: none;
        }

        a.logout-link:hover {
            color: #bf2c38;
        }
        
    </style>
    <!-- Add any necessary CSS stylesheets or external libraries here -->
</head>
<body>
<div class="frame"> <!-- Frame container -->

    <h1>Welcome, <?php echo $admin_name; ?>!</h1>
    <!-- Add links to various admin functionalities here -->
    <div class="container">
        <button class="btn"><a href="manage_products.php">Manage Products</a></button>
        <button class="btn"><a href="manage_users.php">Manage Users</a></button>
        <button class="btn"><a href="manage_orders.php">Manage Orders</a></button>
        <!-- Add more buttons as needed -->
    </div>

    <p><a href="admin_logout.php" class="logout-link">Logout</a></p> <!-- Link to admin logout script -->
</div>
</body>
</html>
