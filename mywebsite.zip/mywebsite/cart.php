<?php
// Include database connection code
include_once "db_connection.php";

// Start session to access cart items
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Retrieve cart items from the database for the current user
    $cart_sql = "SELECT products.*, cart.cart_id FROM products INNER JOIN cart ON products.prod_id = cart.prod_id WHERE cart.user_id = ?";
    $stmt_cart = $connection->prepare($cart_sql);
    $stmt_cart->bind_param("i", $user_id);
    $stmt_cart->execute();
    $cart_result = $stmt_cart->get_result();

    if (!$cart_result) {
        die("Error fetching cart items: " . $connection->error);
    }

    // Check if cart has items
    if ($cart_result->num_rows > 0) {
        $cart_items = $cart_result->fetch_all(MYSQLI_ASSOC);
    } else {
        $cart_items = array();
    }

    // Check if the "Remove" button is clicked
    if (isset($_POST['remove'])) {
        $cart_id = $_POST['cart_id'];
        
        // Remove the product from the cart
        $remove_sql = "DELETE FROM cart WHERE cart_id = ?";
        $stmt_remove = $connection->prepare($remove_sql);
        $stmt_remove->bind_param("i", $cart_id);
        $stmt_remove->execute();

        // Redirect to cart.php to reflect the updated cart
        header("Location: cart.php");
        exit();
    }

    // Check if the "Buy Now" button is clicked
    if (isset($_POST['buy'])) {
        // Insert cart items into the orders table
        $insert_order_sql = "INSERT INTO orders (user_id, prod_id, quantity, order_date, status) VALUES (?, ?, ?, NOW(), 'Pending')";
        $stmt_insert_order = $connection->prepare($insert_order_sql);
        foreach ($cart_items as $item) {
            $stmt_insert_order->bind_param("iii", $user_id, $item['prod_id'], $item['quantity']);
            $stmt_insert_order->execute();
        }

        // Clear the cart after successful purchase
        $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
        $stmt_clear_cart = $connection->prepare($clear_cart_sql);
        $stmt_clear_cart->bind_param("i", $user_id);
        $stmt_clear_cart->execute();

        // Redirect to the purchase_confirmation.php
        header("Location: purchase_confirmation.php");
        exit();
    }

} else {
    // User is not logged in, handle accordingly
    echo "User is not logged in.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{
            background-image:url("pic1.gif") ;
        }
        /* Custom CSS for Shopping Cart */
        /* Add your custom styles here */
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>Shopping Cart</h2>
    <h3>Cart Items</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Action</th> <!-- New column for the Remove button -->
                <th></th> <!-- New column for the Buy button -->
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cart_items as $item): ?>
                <tr>
                    <td><?php echo $item['title']; ?></td>
                    <td><?php echo $item['price']; ?></td>
                    <td>
                        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                            <button type="submit" class="btn btn-danger" name="remove">Remove</button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" action="process_purchase.php">
                            <input type="hidden" name="prod_id" value="<?php echo $item['prod_id']; ?>">
                            <input type="hidden" name="quantity" value="1"> <!-- Default quantity as 1 -->
                            <button type="submit" class="btn btn-success" name="buy_individual">Buy</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if (!empty($cart_items)): ?>
    <div class="container mt-5">
        <!-- "Buy All" button -->
        <form method="POST" action="process_purchase.php">
            <?php foreach ($cart_items as $item): ?>
                <input type="hidden" name="prod_id" value="<?php echo $item['prod_id']; ?>">
                <input type="hidden" name="quantity" value="1"> <!-- Default quantity as 1 -->
            <?php endforeach; ?>
        </form>
    </div>
<?php else: ?>
    <div class="container mt-5">
        <p>Your cart is empty. Please add items to your cart before proceeding.</p>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <a href="index.php" class="btn btn-primary">Continue Shopping</a>
</div>
</body>
</html>

