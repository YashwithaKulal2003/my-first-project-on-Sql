<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer Example</title>
    <style>
        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .footer-content p {
            margin: 0;
        }

        .footer-links ul {
            list-style-type: none;
            padding: 0;
        }

        .footer-links ul li {
            display: inline;
            margin-right: 20px;
        }

        .footer-links ul li:last-child {
            margin-right: 0;
        }

        .footer-links ul li a {
            color: #fff;
            text-decoration: none;
        }

        .footer-links ul li a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <footer>
        
        <div class="footer-links">
            <ul>
                <h4><li><a href="index.php">Home</a></li></h4><br>
                <h4><li>Designed by</h4>Yashwitha M<br>Yuktha K S<br></li>
                <li><a href="#">Contact Us:+1234567890</a></li>
                <h4><li>Secure Shopping | Fast Shipping | Top Brands.</li></h4>
            </ul>
        </div>
    </footer>
</body>
</html>
